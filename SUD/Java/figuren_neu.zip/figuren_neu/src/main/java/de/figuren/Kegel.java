package de.figuren;

public class Kegel extends DreidimensionaleFigur {
    private Kreis grundflaeche;
    private double hoehe;

    public Kegel(Kreis grundflaeche, double hoehe) {
        this.grundflaeche = grundflaeche;
        this.hoehe = hoehe;
    }

    @Override
    public double berechneUmfang() {
        return 2 * Math.PI * grundflaeche.getRadius();
    }

    @Override
    public double berechneFlaeche() {
        double s = Math.sqrt(Math.pow(grundflaeche.getRadius(), 2) + Math.pow(hoehe, 2));
        return Math.PI * grundflaeche.getRadius() * (grundflaeche.getRadius() + s);
    }

    @Override
    public double berechneVolumen() {
        return (1.0 / 3.0) * grundflaeche.berechneFlaeche() * hoehe;
    }
}