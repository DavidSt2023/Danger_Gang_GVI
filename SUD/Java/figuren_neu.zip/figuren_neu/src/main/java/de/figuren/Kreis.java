package de.figuren;

public class Kreis extends Figur {
    private double radius;

    public Kreis(double radius) {
        setRadius(radius);
    }

    public Kreis(Kreis other) {
        this(other.radius);
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        if (radius < 0) {
            throw new IllegalArgumentException("Radius darf nicht negativ sein.");
        }
        this.radius = radius;
    }

    @Override
    public double berechneUmfang() {
        return 2 * Math.PI * radius;
    }

    @Override
    public double berechneFlaeche() {
        return Math.PI * radius * radius;
    }
}