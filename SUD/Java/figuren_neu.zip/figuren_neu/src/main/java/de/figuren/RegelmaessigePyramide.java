package de.figuren;

public class RegelmaessigePyramide extends Pyramide {
    private double seitenlaenge;
    private int anzahlSeiten;

    public RegelmaessigePyramide(double seitenlaenge, int anzahlSeiten, double hoehe) {
        super(new Rechteck(seitenlaenge, seitenlaenge), hoehe);
        this.seitenlaenge = seitenlaenge;
        this.anzahlSeiten = anzahlSeiten;
    }

    @Override
    public double berechneUmfang() {
        return seitenlaenge * anzahlSeiten;
    }

    @Override
    public double berechneFlaeche() {
        double apothem = Math.sqrt(Math.pow(seitenlaenge / (2 * Math.tan(Math.PI / anzahlSeiten)), 2) + Math.pow(super.hoehe, 2));
        return (berechneUmfang() * apothem) / 2 + super.berechneFlaeche();
    }
}