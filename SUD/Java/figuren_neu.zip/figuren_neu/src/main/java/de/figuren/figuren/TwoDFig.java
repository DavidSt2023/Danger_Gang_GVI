package de.figuren.figuren;

public enum TwoDFig {
  TRIANGLE, CIRCLE, RECTANGLE, POLYGON
}
