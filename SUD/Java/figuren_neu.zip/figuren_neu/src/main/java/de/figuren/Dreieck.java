package de.figuren;

public class Dreieck extends Figur {
    private double seiteA;
    private double seiteB;
    private double seiteC;

    public Dreieck(double seiteA, double seiteB, double seiteC) {
        if (!istKonstruktionsfaehig(seiteA, seiteB, seiteC)) {
            throw new IllegalArgumentException("Das Dreieck ist nicht konstruierbar.");
        }
        this.seiteA = seiteA;
        this.seiteB = seiteB;
        this.seiteC = seiteC;
    }

    public Dreieck(Dreieck other) {
        this(other.seiteA, other.seiteB, other.seiteC);
    }

    public double getSeiteA() {
        return seiteA;
    }

    public void setSeiteA(double seiteA) {
        if (!istKonstruktionsfaehig(seiteA, this.seiteB, this.seiteC)) {
            throw new IllegalArgumentException("Das Dreieck ist nicht konstruierbar.");
        }
        this.seiteA = seiteA;
    }

    public double getSeiteB() {
        return seiteB;
    }

    public void setSeiteB(double seiteB) {
        if (!istKonstruktionsfaehig(this.seiteA, seiteB, this.seiteC)) {
            throw new IllegalArgumentException("Das Dreieck ist nicht konstruierbar.");
        }
        this.seiteB = seiteB;
    }

    public double getSeiteC() {
        return seiteC;
    }

    public void setSeiteC(double seiteC) {
        if (!istKonstruktionsfaehig(this.seiteA, this.seiteB, seiteC)) {
            throw new IllegalArgumentException("Das Dreieck ist nicht konstruierbar.");
        }
        this.seiteC = seiteC;
    }

    @Override
    public double berechneUmfang() {
        return seiteA + seiteB + seiteC;
    }

    @Override
    public double berechneFlaeche() {
        double s = berechneUmfang() / 2;
        return Math.sqrt(s * (s - seiteA) * (s - seiteB) * (s - seiteC));
    }

    private boolean istKonstruktionsfaehig(double a, double b, double c) {
        return a + b > c && a + c > b && b + c > a;
    }
}