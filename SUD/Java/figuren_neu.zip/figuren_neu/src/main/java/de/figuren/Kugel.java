package de.figuren;

public class Kugel extends DreidimensionaleFigur {
    private Kreis schnittkreis;

    public Kugel(Kreis schnittkreis) {
        this.schnittkreis = schnittkreis;
    }

    @Override
    public double berechneUmfang() {
        return 2 * Math.PI * schnittkreis.getRadius();
    }

    @Override
    public double berechneFlaeche() {
        return 4 * Math.PI * Math.pow(schnittkreis.getRadius(), 2);
    }

    @Override
    public double berechneVolumen() {
        return (4.0 / 3.0) * Math.PI * Math.pow(schnittkreis.getRadius(), 3);
    }
}