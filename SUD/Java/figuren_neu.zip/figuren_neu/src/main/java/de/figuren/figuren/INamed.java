package de.figuren.figuren;

public interface INamed {

  public String name();
}
