package de.figuren;

public class KlassenDiagrammLink {
    //
}
