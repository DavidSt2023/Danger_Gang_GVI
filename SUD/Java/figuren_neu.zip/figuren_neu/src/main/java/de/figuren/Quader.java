package de.figuren;

public class Quader extends DreidimensionaleFigur {
    private Rechteck grundflaeche;
    private double hoehe;

    public Quader(Rechteck grundflaeche, double hoehe) {
        this.grundflaeche = grundflaeche;
        this.hoehe = hoehe;
    }

    @Override
    public double berechneUmfang() {
        return 4 * (grundflaeche.getLaenge() + grundflaeche.getBreite() + hoehe);
    }

    @Override
    public double berechneFlaeche() {
        return 2 * (grundflaeche.berechneFlaeche() + grundflaeche.getLaenge() * hoehe + grundflaeche.getBreite() * hoehe);
    }

    @Override
    public double berechneVolumen() {
        return grundflaeche.berechneFlaeche() * hoehe;
    }
}