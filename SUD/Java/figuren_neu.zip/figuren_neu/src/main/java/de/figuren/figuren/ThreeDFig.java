package de.figuren.figuren;

public enum ThreeDFig {
  SPHERE, CYLINDER, PRISM, REGULARPRISM, REGULARPYRAMID, CONE
}
