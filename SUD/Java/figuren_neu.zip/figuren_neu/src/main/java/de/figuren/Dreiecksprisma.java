package de.figuren;

public class Dreiecksprisma extends DreidimensionaleFigur {
    private Dreieck grundflaeche;
    private double hoehe;

    public Dreiecksprisma(Dreieck grundflaeche, double hoehe) {
        this.grundflaeche = grundflaeche;
        this.hoehe = hoehe;
    }

    @Override
    public double berechneUmfang() {
        return 2 * grundflaeche.berechneUmfang() + 3 * hoehe;
    }

    @Override
    public double berechneFlaeche() {
        return 2 * grundflaeche.berechneFlaeche() + grundflaeche.berechneUmfang() * hoehe;
    }

    @Override
    public double berechneVolumen() {
        return grundflaeche.berechneFlaeche() * hoehe;
    }
}