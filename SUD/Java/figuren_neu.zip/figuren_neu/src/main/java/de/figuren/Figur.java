package de.figuren;

public abstract class Figur {
    public abstract double berechneUmfang();
    public abstract double berechneFlaeche();
}