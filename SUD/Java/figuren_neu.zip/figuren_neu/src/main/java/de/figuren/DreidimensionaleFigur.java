package de.figuren;

public abstract class DreidimensionaleFigur extends Figur {
    public abstract double berechneVolumen();
}