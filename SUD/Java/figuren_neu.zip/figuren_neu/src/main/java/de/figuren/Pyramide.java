package de.figuren;

public class Pyramide extends DreidimensionaleFigur {
    private Rechteck grundflaeche;
    protected double hoehe;

    public Pyramide(Rechteck grundflaeche, double hoehe) {
        this.grundflaeche = grundflaeche;
        this.hoehe = hoehe;
    }

    @Override
    public double berechneUmfang() {
        return grundflaeche.berechneUmfang();
    }

    @Override
    public double berechneFlaeche() {
        double s = Math.sqrt(Math.pow(grundflaeche.getLaenge() / 2, 2) + Math.pow(hoehe, 2));
        return grundflaeche.berechneFlaeche() + grundflaeche.getLaenge() * s + grundflaeche.getBreite() * s;
    }

    @Override
    public double berechneVolumen() {
        return (1.0 / 3.0) * grundflaeche.berechneFlaeche() * hoehe;
    }
}