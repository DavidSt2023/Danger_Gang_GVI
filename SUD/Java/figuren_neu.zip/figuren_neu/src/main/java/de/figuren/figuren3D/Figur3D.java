package de.figuren.figuren3D;

public abstract class Figur3D {

  public abstract String name();

  public abstract double volumen();

  public abstract double oberflaeche();

  protected Figur3D() {
  }

}