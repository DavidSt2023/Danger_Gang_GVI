package de.figuren;

public class Rechteck extends Figur {
    private double laenge;
    private double breite;

    public Rechteck(double laenge, double breite) {
        setLaenge(laenge);
        setBreite(breite);
    }

    public Rechteck(Rechteck other) {
        this(other.laenge, other.breite);
    }

    public double getLaenge() {
        return laenge;
    }

    public void setLaenge(double laenge) {
        if (laenge < 0) {
            throw new IllegalArgumentException("Länge darf nicht negativ sein.");
        }
        this.laenge = laenge;
    }

    public double getBreite() {
        return breite;
    }

    public void setBreite(double breite) {
        if (breite < 0) {
            throw new IllegalArgumentException("Breite darf nicht negativ sein.");
        }
        this.breite = breite;
    }

    @Override
    public double berechneUmfang() {
        return 2 * (laenge + breite);
    }

    @Override
    public double berechneFlaeche() {
        return laenge * breite;
    }
}