package de.figuren;

public class Zylinder extends DreidimensionaleFigur {
    private Kreis grundflaeche;
    private double hoehe;

    public Zylinder(Kreis grundflaeche, double hoehe) {
        this.grundflaeche = grundflaeche;
        this.hoehe = hoehe;
    }

    @Override
    public double berechneUmfang() {
        return 2 * Math.PI * grundflaeche.getRadius();
    }

    @Override
    public double berechneFlaeche() {
        return 2 * grundflaeche.berechneFlaeche() + berechneUmfang() * hoehe;
    }

    @Override
    public double berechneVolumen() {
        return grundflaeche.berechneFlaeche() * hoehe;
    }
}