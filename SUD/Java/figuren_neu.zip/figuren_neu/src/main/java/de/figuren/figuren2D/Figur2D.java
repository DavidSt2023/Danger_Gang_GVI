package de.figuren.figuren2D;

public abstract class Figur2D {

  public abstract double umfang();

  public abstract double flaeche();
}