package de.figuren.figuren2D;

import de.figuren.figuren.INamed;

public abstract class Figur2D implements INamed {

  public abstract double umfang();

  public abstract double flaeche();
}