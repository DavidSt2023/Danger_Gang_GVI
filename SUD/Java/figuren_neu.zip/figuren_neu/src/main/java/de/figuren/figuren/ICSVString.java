package de.figuren.figuren;

public interface ICSVString {
  public String toCSVString();
}
