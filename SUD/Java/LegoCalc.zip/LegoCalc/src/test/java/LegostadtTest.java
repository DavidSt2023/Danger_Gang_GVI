import java.util.ArrayList;
import java.util.List;

public class LegostadtTest {
    public static void main(String[] args) {
        try {
            LegoStein stein = new LegoStein("Rot", 30, 0.23);
            LegoStein stein1 = new LegoStein("Gelb", 2, 0.32);
            List<LegoBauteil> list = new ArrayList<>();
            list.add(stein);
            list.add(stein1);
            LegoComp comp = new LegoComp(list);
            LegoComp comp1 = new LegoComp();
            comp1.addTeil(stein);
            comp1.addTeil(stein1);
            List<LegoComp> comps = new ArrayList<>();
            comps.add(comp);
            comps.add(comp1);
            Legostadt stadt = new Legostadt();
            stadt.addTeil(comp);
            stadt.addTeil(comp1);
            Legostadt stadt1 = new Legostadt(comps);

            if (stadt1.berechnePreis() == stadt.berechnePreis() && stadt.berechnePreis() == 2*0.23+2*0.32) {
                System.out.println("Berechnung Erfolgreich");
                System.out.println(stadt.berechnePreis() + " ist der Gesamtpreis der Legostadt");
            }

        }
        catch (Exception e) {
            System.out.println("Es ist ein unerwarteter Fehler aufgetreten oder so");
        }
    }
}
