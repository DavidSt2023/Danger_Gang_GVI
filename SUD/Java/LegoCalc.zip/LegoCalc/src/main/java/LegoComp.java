import java.util.ArrayList;
import java.util.List;

public class LegoComp {
    List<LegoBauteil> teile = new ArrayList<>();

    double preis() {
        double preis = 0;
        for (LegoBauteil bauteil : teile) {
            preis += bauteil.preis();
        }
        return preis;
    }

    public void addTeil(LegoBauteil bauteil) {
        teile.add(bauteil);
    }

    public LegoComp(List<LegoBauteil> teile) {
        this.teile = teile;
    }

    public LegoComp(){}
}
