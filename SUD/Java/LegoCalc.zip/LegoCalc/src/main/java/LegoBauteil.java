public abstract class LegoBauteil {

    abstract double preis();
}
