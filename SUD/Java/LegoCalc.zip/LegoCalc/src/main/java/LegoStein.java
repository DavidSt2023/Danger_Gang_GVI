public class LegoStein extends LegoBauteil {
    String farbe;
    int groesse;
    double preis;

    public LegoStein(String farbe, int groesse, double preis) {
        this.farbe = farbe;
        this.groesse = groesse;
        this.preis = preis;
    }


    @Override
    double preis() {
        return this.preis;
    }
}
