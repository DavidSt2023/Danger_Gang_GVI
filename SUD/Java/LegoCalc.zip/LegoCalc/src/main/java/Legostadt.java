import java.util.ArrayList;
import java.util.List;

public class Legostadt {
    List<LegoComp> teile = new ArrayList<>();

    public Legostadt(List<LegoComp> legoComps){
        this.teile = legoComps;
    }

    public Legostadt(){}

    public double berechnePreis() {
        double preis = 0;
        for (LegoComp comp : teile) {
            preis += comp.preis();
        }
        return preis;
    }

    public void addTeil(LegoComp comp){
        teile.add(comp);
    }
}
