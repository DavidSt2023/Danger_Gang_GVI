import java.util.ArrayList;
import java.util.List;
import mitarbeiter.Bueroarbeiter;
import mitarbeiter.Manager;
import mitarbeiter.Mitarbeiter;
import mitarbeiter.SchichtArbeiter;

public class Mitarbeiterverwaltung {

  private List<Mitarbeiter> mitarbeiterListe;

  public Mitarbeiterverwaltung() {
    mitarbeiterListe = new ArrayList<>();
  }

  public void addMitarbeiter(Mitarbeiter m) {
    mitarbeiterListe.add(m);
  }

  public void removeMitarbeiter(Mitarbeiter m) {
    mitarbeiterListe.remove(m);
  }

  public List<Mitarbeiter> getMitarbeiterListe() {
    return mitarbeiterListe;
  }

  public void printMitarbeiter() {
    for (Mitarbeiter m : mitarbeiterListe) {
      System.out.println(m.toString());
    }
  }

  public double getEinkommen() {
    double einkommen = 0;
    for (Mitarbeiter m : mitarbeiterListe) {

      if (m instanceof SchichtArbeiter s) {
        einkommen += s.einkommen();
      } else if (m instanceof Manager ma) {
        einkommen += ma.getFestgehalt() + ma.getBonus();
      } else if (m instanceof Bueroarbeiter b) {
        einkommen += b.getFestgehalt();
      } else {
        throw new IllegalArgumentException("Mitarbeiterklasse nicht bekannt.");
      }
    }
    return einkommen;
  }

}
