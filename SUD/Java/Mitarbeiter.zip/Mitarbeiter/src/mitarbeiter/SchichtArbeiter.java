package mitarbeiter;

public class SchichtArbeiter extends Mitarbeiter{

  private double stundenSatz;
  private int anzahlStunden;

  public SchichtArbeiter(int id, String name, double stundenSatz) {
    super(name);
    setId(id);
    this.stundenSatz = stundenSatz;
  }

  public double einkommen() {
    return stundenSatz * anzahlStunden;
  }

  @Override
  protected void setId(int id) {
    if (id < 3000 || id > 3999) {
      throw new IllegalArgumentException("Die Id muss positiv 4 stellig sein und mit der Ziffer 3 beginnen.");
    }
    super.setId(id);
  }

  protected void setAnzahlStunden(int anzahlStunden) {
    if (anzahlStunden < 0) {
      throw new IllegalArgumentException("Die Anzahl der Stunden darf nicht negativ sein.");
    }
    this.anzahlStunden += anzahlStunden;
  }

  public void arbeite() {
    this.anzahlStunden += 8;
  }

  public void arbeite(int anzahlStunden) {
    setAnzahlStunden(anzahlStunden);
  }

  @Override
  public String toString() {
    return "mitarbeiter.SchichtArbeiter [id=" + getId() + ", name=" + getName() + ", stundenSatz=" + stundenSatz + ", anzahlStunden=" + anzahlStunden + ", einkommen=" + einkommen() + "]";
  }

}
