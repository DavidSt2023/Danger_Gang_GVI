package mitarbeiter;

public class Mitarbeiter {

  private int id;
  private String name;


  public Mitarbeiter(int id, String name) {
    setId(id);
    setName(name);
  }

  public Mitarbeiter(String name) {
    setName(name);
  }

  public Mitarbeiter(Mitarbeiter m) {
    this.setId(m.getId());
    this.setName(m.getName());
  }

  public int getId() {
    return id;
  }

  protected void setId(int id) {
    validateId(id);
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    validateName(name);
    this.name = name;
  }

  public String toString() {
    return "mitarbeiter.Mitarbeiter [id=" + id + ", name=" + name + "]";
  }

  private void validateName(String name){
    if (name == null || name.isBlank()) {
      throw new IllegalArgumentException("Der Name darf nicht leer sein.");
    } else if (name.charAt(0) != name.toUpperCase().charAt(0)) {
      throw new IllegalArgumentException("Der Name muss mit einem Großbuchstaben beginnen.");
    } else if (!name.matches("^[A-Z][a-zA-Z_\\-\\s]*$")) {
      throw new IllegalArgumentException("Der Name darf nur Buchstaben, Leerzeichen, sowie Unter- und Bindestriche enthalten.");
    } else if (name.length() < 3) {
      throw new IllegalArgumentException("Der Name muss mindestens 3 Zeichen lang sein.");
    } else if (name.length() > 50) {
      throw new IllegalArgumentException("Der Name darf maximal 50 Zeichen lang sein.");
    }
  }

  private void validateId(int id){
    if (id < 1000 || id > 9999) {
      throw new IllegalArgumentException("Die Id muss 4 stellig und positiv sein.");
    }
  }

}
