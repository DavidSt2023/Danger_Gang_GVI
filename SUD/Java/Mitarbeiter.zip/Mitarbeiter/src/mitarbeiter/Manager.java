package mitarbeiter;

public class Manager extends Bueroarbeiter {

  private double bonus;

  public Manager(int id, String name, double festgehalt, double prozentsatz) {
    super(id, name, festgehalt);
    setBonus(prozentsatz);
  }

  public void setBonus(double prozentsatz) {
    if (prozentsatz < 0) {
      throw new IllegalArgumentException("Der Prozentsatz darf nicht negativ sein.");
    }
    this.bonus = getFestgehalt() * prozentsatz;
  }

  public double getBonus() {
    return bonus;
  }

  @Override
  public String toString() {
    return "mitarbeiter.Manager [id=" + getId() + ", name=" + getName() + ", festgehalt=" + getFestgehalt() + ", bonus=" + getBonus() + "]";
  }
}
