package mitarbeiter;

public class Bueroarbeiter extends Mitarbeiter {

  private double festgehalt;

  public Bueroarbeiter(int id, String name, double festgehalt) {
    super(id, name);
    setFestgehalt(festgehalt);
  }

  public void setFestgehalt(double festgehalt) {
    if (festgehalt < 0) {
      throw new IllegalArgumentException("Das Festgehalt darf nicht negativ sein.");
    }
    this.festgehalt = festgehalt;
  }

  public double getFestgehalt() {
    return festgehalt;
  }

  @Override
  protected void setId(int id) {
    if (id < 5000 || id > 5999) {
      throw new IllegalArgumentException("Die Id muss positiv 4 stellig sein und mit der Ziffer 5 beginnen.");
    }
    super.setId(id);
  }

  @Override
  public String toString() {
    return "mitarbeiter.Bueroarbeiter [id=" + getId() + ", name=" + getName() + ", festgehalt=" + getFestgehalt() + "]";
  }


}
