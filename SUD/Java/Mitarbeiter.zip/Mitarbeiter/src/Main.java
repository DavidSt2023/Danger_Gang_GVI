import autos.Personenkraftfahrzeug;
import autos.Bus;
import mitarbeiter.Bueroarbeiter;
import mitarbeiter.Manager;
import mitarbeiter.SchichtArbeiter;

public class Main {

  public static void main(String[] args) {
    System.out.println("mitarbeiter.Mitarbeiter Aufgabe von Lukas Leufen");

    Mitarbeiterverwaltung mv = new Mitarbeiterverwaltung();

    SchichtArbeiter s1 = new SchichtArbeiter(3001, "Hans", 10);
    s1.arbeite(10);
    mv.addMitarbeiter(s1);

    SchichtArbeiter s2 = new SchichtArbeiter(3002, "Peter", 12);
    s2.arbeite(8);
    mv.addMitarbeiter(s2);

    Bueroarbeiter b1 = new Bueroarbeiter(5001, "Klaus", 2000);
    mv.addMitarbeiter(b1);

    Manager m1 = new Manager(5002, "Karl", 3000, 0.1);
    mv.addMitarbeiter(m1);

    mv.printMitarbeiter();
    System.out.println("Gesamteinkommen: " + mv.getEinkommen());

    System.out.println("autos.Personenkraftfahrzeug Aufgabe von Lukas Leufen");

    Personenkraftfahrzeug pkw = new Personenkraftfahrzeug(200, 50, 5);
    pkw.einsteigen();
    pkw.einsteigen();
    System.out.println(pkw.getStatus());
    pkw.aussteigen();
    pkw.refuel(60);
    System.out.println(pkw.getStatus());
    pkw.startMotor();
    pkw.drive(100);
    pkw.stopMotor();
    System.out.println(pkw.getStatus());

    System.out.println("autos.Bus Aufgabe von Lukas Leufen");

    Bus bus = new Bus(100, 100, 50, "Alfred");
    bus.einsteigen();
    bus.einsteigen();
    System.out.println(bus.getStatus());
    bus.aussteigen();
    bus.refuel(60);
    System.out.println(bus.getStatus());
    bus.startMotor();
    bus.drive(100);
    bus.stopMotor();
    System.out.println(bus.getStatus());

  }
}