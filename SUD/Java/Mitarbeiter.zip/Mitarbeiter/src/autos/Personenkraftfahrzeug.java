package autos;

public class Personenkraftfahrzeug extends Car{

  private int anzahlSitze;
  private int anzahlPassagiere;

  public Personenkraftfahrzeug(double maxSpeed, double maxFuelLevel, int anzahlSitze) {
    super(maxSpeed, maxFuelLevel);
    setAnzahlSitze(anzahlSitze);
  }

  public void setAnzahlSitze(int anzahlSitze) {
    if (anzahlSitze < 0) {
      throw new IllegalArgumentException("Die Anzahl der Sitze darf nicht negativ sein.");
    }

    this.anzahlSitze = anzahlSitze;
  }

  public void einsteigen() {
    if (anzahlPassagiere < anzahlSitze) {
      anzahlPassagiere++;
    } else {
      throw new IllegalStateException("Das Fahrzeug ist voll.");
    }
  }

  public void aussteigen() {
    if (anzahlPassagiere > 0) {
      anzahlPassagiere--;
    } else {
      throw new IllegalStateException("Das Fahrzeug ist leer.");
    }
  }

  protected int getAnzahlPassagiere() {
    return anzahlPassagiere;
  }

  protected int getAnzahlSitze() {
    return anzahlSitze;
  }

  @Override
  public String getStatus() {
    return super.getStatus().replace("]", "").replace("Car", "Personenkraftfahrzeug") + ", Passagiere: " + anzahlPassagiere + "/" + anzahlSitze + "]";
  }

}
