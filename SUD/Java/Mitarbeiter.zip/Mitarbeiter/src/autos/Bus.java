package autos;

public class Bus extends Personenkraftfahrzeug {

  private String fahrer;

  public Bus(double maxSpeed, double maxFuelLevel, int anzahlSitze, String fahrer) {
    super(maxSpeed, maxFuelLevel, anzahlSitze);
    setFahrer(fahrer);
  }

  public void setFahrer(String fahrer) {
    if (fahrer == null || fahrer.isBlank()) {
      throw new IllegalArgumentException("Der Fahrer darf nicht leer sein.");
    }
    this.fahrer = fahrer;
  }

  public String getFahrer() {
    return fahrer;
  }

  @Override
  public String getStatus() {
    return super.getStatus().replace("]", "").replace("Personenkraftfahrzeug", "Bus") + ", Fahrer: " + getFahrer() + "]";
  }

}
