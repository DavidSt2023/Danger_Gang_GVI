package autos;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class Car {
  private boolean isMotorRunning = false;
  private double currentSpeed = 0;
  private double maxSpeed;
  private double currentFuelLevel = 0;
  private double maxFuelLevel;
  private double currentMileage = 0;

  public Car(double maxSpeed, double maxFuelLevel) {
    setMaxSpeed(maxSpeed);
    setMaxFuelLevel(maxFuelLevel);
  }

  public Car(double maxSpeed, double maxFuelLevel, double currentFuelLevel, double currentMileage) {
    setMaxSpeed(maxSpeed);
    setMaxFuelLevel(maxFuelLevel);
    setCurrentFuelLevel(currentFuelLevel);
    setCurrentMileage(currentMileage);
  }

  public boolean isMotorRunning() {
    return isMotorRunning;
  }

  public double getCurrentSpeed() {
    return currentSpeed;
  }

  public double getMaxSpeed() {
    return maxSpeed;
  }

  public void setMaxSpeed(double maxSpeed) {
    if (maxSpeed <= 0) {
      throw new IllegalArgumentException("Max speed must be greater than 0.");
    }
    this.maxSpeed = maxSpeed;
  }

  public double getCurrentFuelLevel() {
    return currentFuelLevel;
  }

  public void setCurrentFuelLevel(double currentFuelLevel) {
    if (currentFuelLevel < 0) {
      throw new IllegalArgumentException("Current fuel level must be greater than or equal to 0.");
    }
    if (currentFuelLevel > maxFuelLevel) {
      throw new IllegalArgumentException("Current fuel level must be less than or equal to max fuel level.");
    }

    this.currentFuelLevel = currentFuelLevel;
  }

  public double getMaxFuelLevel() {
    return maxFuelLevel;
  }

  public void setMaxFuelLevel(double maxFuelLevel) {
    if (maxFuelLevel <= 0) {
      throw new IllegalArgumentException("Max fuel level must be greater than 0.");
    }
    this.maxFuelLevel = maxFuelLevel;
  }

  public double getCurrentMileage() {
    return currentMileage;
  }

  public void setCurrentMileage(double currentMileage) {
    if (currentMileage < 0) {
      throw new IllegalArgumentException("Current mileage must be greater than or equal to 0.");
    }
    this.currentMileage = currentMileage;
  }

  public void startMotor() {
    if (isMotorRunning) {
      System.out.println("Motor is already running.");
      return;
    }
    if (currentFuelLevel <= 0) {
      System.out.println("Cannot start motor. Fuel tank is empty.");
      return;
    }
    System.out.println("Starting motor...");
    isMotorRunning = true;
  }

  public void stopMotor() {
    if (!isMotorRunning) {
      System.out.println("Motor is already stopped.");
      return;
    }
    System.out.println("Stopping motor...");
    isMotorRunning = false;
  }

  public void accelerate() {
    if (!isMotorRunning) {
      System.out.println("Motor is not running. Cannot accelerate.");
      return;
    }
    if (currentSpeed + 10 > maxSpeed) {
      System.out.println("Cannot accelerate. Max speed reached.");
      return;
    }
    currentSpeed += 10;
    System.out.println("Accelerating... current speed: " + currentSpeed);
  }

  public void decelerate() {
    if (!isMotorRunning) {
      System.out.println("Motor is not running. Cannot decelerate.");
      return;
    }
    if (currentSpeed - 10 < 0) {
      System.out.println("Cannot decelerate. Min speed reached.");
      return;
    }
    currentSpeed -= 10;
    System.out.println("Decelerating... current speed: " + currentSpeed);
  }

  public void refuel(double fuel) {
    if (fuel <= 0) {
      throw new IllegalArgumentException("Fuel must be greater than 0.");
    }
    if (isMotorRunning) {
      System.out.println("Cannot refuel. Motor is running.");
      return;
    }
    if (currentFuelLevel == maxFuelLevel) {
      System.out.println("Cannot refuel. Fuel tank is full.");
      return;
    }
    if (currentFuelLevel + fuel > maxFuelLevel) {
      System.out.println("Refueling... Fuel tank will be overfilled. Overfilled amount " + (currentFuelLevel + fuel - maxFuelLevel));
      currentFuelLevel = maxFuelLevel;
      return;
    }

    currentFuelLevel += fuel;
    System.out.println("Refueling... added fuel: " + fuel);
  }

  public void drive(double distance) {
    if (!isMotorRunning) {
      System.out.println("Cannot drive. Motor is not running.");
      return;
    }
    if (currentFuelLevel <= 0) {
      System.out.println("Cannot drive. Fuel tank is empty.");
      return;
    }

    double fuelConsumed = new BigDecimal(distance / 100 * 6).setScale(2, RoundingMode.HALF_UP).doubleValue();
    if (currentFuelLevel >= fuelConsumed) {
      currentFuelLevel -= fuelConsumed;
      currentMileage += distance;
      System.out.println("Driving... current milage: " + currentMileage + ", consumed fuel: " + fuelConsumed);
    } else {
      System.out.println("Cannot drive. Not enough fuel.");
    }
  }

  public String getMasterData() {
    return "autos.Car [Master data: Max speed: " + maxSpeed +
        ", Max fuel level: " + maxFuelLevel + "]";
  }

  protected String getStatus() {
    return "autos.Car [Status: Current speed: " + currentSpeed +
        ", Max speed: " + maxSpeed +
        ", Motor running: " + isMotorRunning +
        ", Current fuel level: " + currentFuelLevel +
        ", Max fuel level: " + maxFuelLevel +
        ", Current milage: " + currentMileage + "]";
  }
}
